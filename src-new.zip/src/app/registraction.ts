
export class Registraction {
    id:number;
    name:string;
    email:string;
    password:string;
    confirmPassword:string;
}

export interface LoginUser{
    email:string;
    password:string;
}