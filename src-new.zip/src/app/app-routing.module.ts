import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserListComponent } from './users/user-list/user-list.component';
import { UserCreateComponent } from './users/user-create/user-create.component';

const routes: Routes = [
  { path:'login', component:LoginComponent},
  { path:'register', component:RegistrationComponent},
  { path:'dashboard', component:DashboardComponent},
  { path:'user-list', component:UserListComponent},
  { path:'user-create', component:UserCreateComponent},
  { path:'', redirectTo:'login', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
