
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn:'root'
})
export class registractionService{
constructor(private http:HttpClient){}

baseURL="http://localhost:3000/register";

 

register(user: any){
    return this.http.post(`${this.baseURL}`,user);

   /// console.log("testing service "+this.http.post(`${this.baseURL}`,user));
}

}