import { Component, OnInit } from '@angular/core';

import {Registraction } from '../registraction';
import { registractionService } from '../registration/registractionService'
import { Router, ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  regUser:Registraction[];
  regUserForm:FormGroup;
  constructor(private router: Router, private route: ActivatedRoute, private fb:FormBuilder, private regService:registractionService ) { 
    this.registerDetails();
  }

  submitted=false;
  loading=false;
  registerDetails(){
    this.regUserForm= this.fb.group({
      name:['',[Validators.required,Validators.minLength(6)]],
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required],
      confirmPassword:['',Validators.required]
    })
  }

  ngOnInit() {
  }

  regUserFormSubmit(data){

    console.log("rd "+data);
    this.submitted=true;
    if(this.regUserForm.invalid){
      return;
    }
    this.loading =true;
    this.regService.register(this.regUserForm.value).subscribe(
      (data)=>{
      this.router.navigate(['/login']);
    })
  }

}
