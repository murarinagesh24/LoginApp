import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:HttpClient) { }

 
validateUser(register :any){
  return this.http.get<any>('http://localhost:3000/register?email='+register.email+'&password='+register.password);
}

loginUser(name:string){
    return this.http.get<any>('http://localhost:3000/register?name='+name);

}

}